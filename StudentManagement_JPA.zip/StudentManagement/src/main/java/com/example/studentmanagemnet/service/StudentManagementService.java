/*
 * Copyright (c) 2024 Student Corporation.
 */

package com.example.studentmanagemnet.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.studentmanagemnet.model.Student;
import com.example.studentmanagemnet.repository.StudentRepository;

/**
 * Student management service.
 */
@Service
public class StudentManagementService {

    /** Student repository. */
    @Autowired
    private StudentRepository studentRepository;

    /**
     * Update or create student.
     *
     * @return Student.
     */
    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }

    /**
     * Get all students.
     *
     * @return Student list.
     */
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    /**
     * Get student by ID.
     *
     * @param id Student ID.
     * @return Student.
     */
    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }

    /**
     * Delete student by ID.
     */
    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }
}
