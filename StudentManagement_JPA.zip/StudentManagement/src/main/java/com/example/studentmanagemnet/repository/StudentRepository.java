/*
 * Copyright (c) 2024 Student Corporation.
 */

package com.example.studentmanagemnet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.studentmanagemnet.model.Student;

/**
 * Student repository.
 */
public interface StudentRepository extends JpaRepository<Student, Long> {}
