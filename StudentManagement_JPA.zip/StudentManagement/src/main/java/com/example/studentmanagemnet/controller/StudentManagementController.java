/*
 * Copyright (c) 2024 Student Corporation.
 */

package com.example.studentmanagemnet.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.studentmanagemnet.model.Student;
import com.example.studentmanagemnet.service.StudentManagementService;

/**
 * Student management controller.
 */
@RestController
@RequestMapping("/students")
public class StudentManagementController {

    /** Student management service. */
    @Autowired
    private StudentManagementService service;

    /**
     * Get all student.
     *
     * @return Student list.
     */
    @GetMapping
    public List<Student> getAllStudents() {
        return service.getAllStudents();
    }

    /**
     * Get student by ID.
     *
     * @param id Student ID.
     * @return Student.
     */
    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable Long id) {
        Optional<Student> student = service.getStudentById(id);
        return student.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Create student.
     *
     * @param student Student entity.
     * @return Student.
     */
    @PostMapping
    public ResponseEntity<Student> createStudent(@RequestBody Student student) {
        Student savedStudent = service.saveStudent(student);
        return ResponseEntity.ok(savedStudent);
    }

    /**
     * Update student.
     *
     * @param id Student ID.
     * @param student Student entity.
     * @return Student or not found.
     */
    @PutMapping("/{id}")
    public ResponseEntity<Student> updateStudent(@PathVariable Long id, @RequestBody Student student) {
        if (service.getStudentById(id).isPresent()) {
            student.setId(id);
            Student updatedStudent = service.saveStudent(student);
            return ResponseEntity.ok(updatedStudent);
        }
        return ResponseEntity.notFound().build();
    }

    /**
     * Delete student.
     *
     * @param id Student ID.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable Long id) {
        if (service.getStudentById(id).isPresent()) {
            service.deleteStudent(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
