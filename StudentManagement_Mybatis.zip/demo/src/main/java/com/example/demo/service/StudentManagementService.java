/*
 * Copyright (c) 2024 Student Corporation.
 */

package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.domain.Student;
import com.example.demo.mapper.StudentMapper;

/**
 * Student management service.
 */
@Service
public class StudentManagementService {

    /** Student mapper. */
    @Autowired
    private StudentMapper studentMapper;

    /**
     * Add student.
     */
    public void addStudent(Student student) {
        studentMapper.insertStudent(student);
    }

    /**
     * Get student by ID.
     *
     * @param id Student ID.
     * @return Student.
     */
    public Student getStudentById(Long id) {
        return studentMapper.getStudentById(id);
    }

    /**
     * Get all students.
     *
     * @return Student list.
     */
    public List<Student> getAllStudents() {
        return studentMapper.getAllStudents();
    }

    /**
     * Update student.
     *
     * @param student Student entity.
     */
    public void updateStudent(Student student) {
        studentMapper.updateStudent(student);
    }

    /**
     * Delete student by ID.
     *
     * @param id Student ID.
     */
    public void deleteStudent(Long id) {
        studentMapper.deleteStudent(id);
    }
}
