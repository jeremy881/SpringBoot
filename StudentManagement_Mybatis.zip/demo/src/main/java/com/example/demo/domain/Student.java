/*
 * Copyright (c) 2024 Student Corporation.
 */

package com.example.demo.domain;

import java.io.Serializable;

/**
 * Student entity.
 */
public class Student implements Serializable {

    /** ID. */
    private Long id;

    /** Name. */
    private String name;

    /** Age. */
    private Integer age;

    /** Major. */
    private String major;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }
}
