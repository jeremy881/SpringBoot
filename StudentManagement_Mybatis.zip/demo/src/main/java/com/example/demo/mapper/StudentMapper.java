/*
 * Copyright (c) 2024 Student Corporation.
 */

package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.domain.Student;

/**
 * Student mapper.
 */
@Mapper
public interface StudentMapper {

    void insertStudent(Student student);

    Student getStudentById(Long id);

    List<Student> getAllStudents();

    void updateStudent(Student student);

    void deleteStudent(Long id);
}