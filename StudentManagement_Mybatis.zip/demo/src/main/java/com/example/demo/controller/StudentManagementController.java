/*
 * Copyright (c) 2024 Student Corporation.
 */

package com.example.demo.controller;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.domain.Student;
import com.example.demo.service.StudentManagementService;

/**
 * Student management controller.
 */
@RestController
@RequestMapping("/students")
public class StudentManagementController {

    /** Student management service. */
    @Autowired
    private StudentManagementService service;

    /**
     * Add student.
     *
     * @param student Student entity.
     */
    @PostMapping
    public void addStudent(@RequestBody Student student) {
        service.addStudent(student);
    }

    /**
     * Get student by ID.
     *
     * @param id Student ID.
     * @return Student.
     */
    @GetMapping(value = "getById", produces = MediaType.APPLICATION_JSON_VALUE)
    public Student getStudentById(@RequestParam(value = "id") Long id) {
        return service.getStudentById(id);
    }

    /**
     * Get all students.
     *
     * @return Student LIst.
     */
    @GetMapping(value = "getAll", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Student> getAllStudents() {
        return service.getAllStudents();
    }

    /**
     * Update student.
     *
     * @param student Student entity.
     * @return Student.
     */
    @PostMapping(value = "updateById")
    public void updateStudent(@RequestBody Student student) {
        if (Objects.nonNull(student.getId())) {
            service.updateStudent(student);
        }
    }

    /**
     * Delete student by ID.
     *
     * @param id Student ID.
     */
    @DeleteMapping(value = "deleteById")
    public void deleteStudent(@RequestParam(value = "id") Long id) {
        service.deleteStudent(id);
    }
}
